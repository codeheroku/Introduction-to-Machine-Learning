import pandas as pd
import matplotlib.pyplot as plt  

### Helper function use when needed
def plot_regression_line(X,m,b):
	regression_x = X.values
	regression_y = []
	for x in regression_x:
		y = m*x + b
		regression_y.append(y)

	plt.plot(regression_x,regression_y)
	plt.pause(1)

##Step 1: Read the CSV file and plot


##Step2: Def a func grad_desc such that it takes m,b and returns a better value of m,b 
##so that the error reduces



